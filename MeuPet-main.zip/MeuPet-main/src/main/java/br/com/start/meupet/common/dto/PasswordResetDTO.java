package br.com.start.meupet.common.dto;

public record PasswordResetDTO(String password) {
}
