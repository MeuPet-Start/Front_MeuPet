package br.com.start.meupet.common.dto;

public record AccessDTO(String token) {

}
